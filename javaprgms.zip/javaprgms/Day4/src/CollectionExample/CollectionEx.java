package CollectionExample;

import java.util.HashSet;
import java.util.Iterator;
import java.util.PriorityQueue;

public class CollectionEx {
	public void HashEx() {
		HashSet<String> hset = new HashSet<String>();
		hset.add("Banglore");
		hset.add("Shimogha");
		hset.add("Mysore");
		hset.add("Manglore");
		hset.add("Mumbai");
		hset.add(null);
		hset.add("Shimogha");
		hset.add("Banglore");
		hset.add(null);
		hset.add(null);
		System.out.println(hset);
		System.out.println();
	}
	
	public void QueueEx() {
		PriorityQueue<String> q= new PriorityQueue<String>();
		q.add("Carrot");
		q.add("Potato");
		q.add("Onion");
	
		q.add("Beans");
		q.add("Peas");
		System.out.println("Head:" +q.element());
		System.out.println("Head:" +q.peek());
		System.out.println("Iterating the Queue Element");
		
		Iterator itr=q.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		q.remove();
		q.poll();
		System.out.println("After removing the elements:");
		
		Iterator itr2 =q.iterator();
		while(itr2.hasNext())
		{
			System.out.println(itr2.next());
		}	
	}	
}
