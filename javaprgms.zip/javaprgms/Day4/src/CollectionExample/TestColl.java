package CollectionExample;

public class TestColl {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CollectionEx c= new CollectionEx();
		c.HashEx();
		c.QueueEx();
	}

}
