package LambdaExp;

public interface SInterface {
	public int intrest(int p, int t, int r);
	
	
}
