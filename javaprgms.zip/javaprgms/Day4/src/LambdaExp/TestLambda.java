package LambdaExp;

public class TestLambda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SInterface s1= (p,t,r)->{
			int si=(p*t*r)/100;
			return si;
		};
		System.out.println("Simple Intrest is: " +s1.intrest(1000, 2, 1));
		
	}

}