package FunctionInterface;

import java.util.function.*;

public class functionalCode {
	static String show(String message) {
		return "Hello" + message;
	}
	static void printMessage(String name) {
		System.out.println("Hello" +name);
	}
	static void printValue(int  val) {
		System.out.println(val);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Predicate<Integer> pr=a -> (a>18);
	System.out.println(pr.test(10));
	
	Function <String, String> fun=  functionalCode::show;
	System.out.println((fun.apply(" Nayana")));
	
	BiFunction<String, String, String> bi=(x, y) -> {return x+y;};
	System.out.println(bi.apply("Hello", " Class"));
	
	Consumer<String> consumer1= functionalCode::printMessage;
	consumer1.accept(" ABC");
	Consumer<Integer> consumer2= functionalCode::printValue;
	consumer2.accept(21);
	
	
	
	
	
	
	
	
	}
	
	
	
	
}

