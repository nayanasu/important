package Exceptions;

public class InvalidageException extends Exception {

	public  InvalidageException(String s)
	{
		super(s);
		
	}
}
