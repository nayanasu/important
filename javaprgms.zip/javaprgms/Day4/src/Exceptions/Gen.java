package Exceptions;

public class Gen {
	
	public void method1() {
		try {
			int x=10/0;
		}catch (Exception e) {
			System.out.println("Divide by zero exception handeled by method 1");
		}
		
	}
	
	public void method2() throws Exception{
		int x=10/0;
	}
	public void checkage(int age) throws InvalidageException
	{
		if(age<18)
			throw new InvalidageException ("Invalid age to vote");
		else
				System.out.println("You are adult and can vote");
	}
	
	public void method3()
	{
		try {
			int x=10/0;
			int[] a= new int[3];
			a[0]=10;
			a[1]=20;
			a[2]=30;
			a[3]=10;
			
		}
	catch(ArithmeticException e) {
		System.out.println("Divide by zero");
	}
	
	catch(ArrayIndexOutOfBoundsException e) {
		System.out.println("Reffering out of array size");
	}
		
	catch(NullPointerException e) {
		System.out.println("RObject is not instantiated");
	} finally {
		System.out.println("Close all the resources");
	}
		
		
		
	}
}
