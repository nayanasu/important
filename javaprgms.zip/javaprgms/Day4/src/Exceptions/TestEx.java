package Exceptions;

public class TestEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Gen g= new Gen();
		g.method1();
		
		try
		{
			g.method2();
		} catch (Exception e) {
			System.out.println("Divide by zero exception handeled by method 2");
		}
		g.method3();
		
		try {
			g.checkage(37);
		}catch (InvalidageException e) {
			System.out.println(e);
		}
		
		
	
		
	}

}
