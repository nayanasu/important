package refer;
interface Sayable{
void say();
}

public class InstRef {
	public void saySomething() {
		System.out.println("Hello, This is non static method");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InstRef methodReference= new InstRef();
		methodReference.saySomething();
		Sayable sayable= methodReference::saySomething;
		//Sayable sayable2 = new InstRef()::saySomething;
		//sayable2.say();
	}

}
