package net;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;

public class FileOutputStreamExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			FileOutputStream fout= new FileOutputStream
			("C:\\Users\\slk\\Desktop\\nayana\\new 1.txt");
			String s="Welcome to class of Java";
			byte b[]= s.getBytes();
			fout.write(b);
			fout.close();
			System.out.println("Success...");
			
			FileInputStream fin= new FileInputStream
				("C:\\Users\\slk\\Desktop\\nayana\\new 1.txt");
			//int i=fin.read();
			//System.out.println((char)i);
			int i=0;
			while((i=fin.read())!= -1) {
				System.out.print((char)i);
			}
			fin.close();
			
			FileWriter fw=new FileWriter("C:\\Users\\slk\\Desktop\\nayana\\new 1.txt");
			fw.write("Welcome to slk");
			fw.close();
			
			FileReader fr=new FileReader("C:\\Users\\slk\\Desktop\\nayana\\new 1.txt");
			int i1;
			while((i1=fr.read())!= -1)
				System.out.print((char)i);
			fr.close();
			
			
		}catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("Sucess....");
	}

}
