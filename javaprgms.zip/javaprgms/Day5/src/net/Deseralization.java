package net;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class Deseralization {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			ObjectInputStream in= new ObjectInputStream(new FileInputStream
			("C:\\\\Users\\\\slk\\\\Desktop\\\\nayana\\\\new 1.txt"));
			Student S1= (Student)in.readObject();
			System.out.println(S1.name +" "+ S1.Serialno + " "+ S1.price);
			in.close();
		} catch( Exception e) {
			System.out.println(e);
		}
	}

}
