package net;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class SeralizationExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Student S1= new Student("Nayana", 2, 50000);
			FileOutputStream fout= new FileOutputStream
			("C:\\\\Users\\\\slk\\\\Desktop\\\\nayana\\\\new 1.txt");
			ObjectOutputStream out= new ObjectOutputStream(fout);
			out.writeObject(S1);
			out.flush();
			out.close();
			System.out.println("Success");
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
