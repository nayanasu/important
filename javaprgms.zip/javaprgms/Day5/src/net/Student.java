package net;

import java.io.Serializable;

public class Student implements Serializable {
	 String name;
	 int Serialno;
	 float price;
	 
	public Student(String name, int serialno, float price) {
		super();
		this.name = name;
		Serialno = serialno;
		this.price = price;	
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSerialno() {
		return Serialno;
	}

	public void setSerialno(int serialno) {
		Serialno = serialno;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}
	 
}
