package net;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Student> ls= new ArrayList<Student>();
		Student s1= new Student("Acer", 4, 25000 );
		Student s2= new Student("ABC", 5, 38000 );		
		ls.add(s1);
		ls.add(s2);
		ls.add( new Student("HP", 1, 20000 ));
		ls.add( new Student("Dell", 2, 30000 ));
		ls.add( new Student("Lenovo", 3, 40000 ));
		for(Student s: ls)
		{
			System.out.println("Name: "+ s.getName() +"\nSerial_Number: "+ s.getSerialno()+ "\nPrice: "+ s.getPrice()+ "\n"); 
			
		}
		List<Float> pr= new ArrayList<Float>();
		List<String> n= new ArrayList<String>();
		for(Student p1:ls) {
		if(p1.price >25000) 
		{
			n.add(p1.name);
			pr.add(p1.price);
			
		}
		}
		System.out.println(pr);
		System.out.println(n);
	

	//List<Float> n1= ls.stream()
	//.filter(x -> x.price>25000)
	//.filter(x -> x.price==25000)
	double totalPrice3=ls.stream()
	.collect(Collectors.summingDouble(Student->Student.price));
	System.out.println(totalPrice3);
	//.map(x -> x.price)
	//.collect(Collectors.toList());
	//System.out.println(n1);
	
	List<String> n2= ls.stream()
			.filter(x -> x.price>25000)
			.map(x -> x.name)
			.collect(Collectors.toList());
			System.out.println(n2);
			
	Student studentA= ls.stream()
			.max((student1, student2)-> 
			student1.price> student2.price ? 1: -1).get();
	System.out.println(studentA.price);
	
	Student studentB= ls.stream()
			.max((student1, student2)->
			student1.price< student2.price ? 1: -1).get();
	System.out.println(studentB.price);
	
	long count= ls.stream()
			.filter(Student-> Student.price<30000)
			.count();
	System.out.println(count);
	
	Set<Float> StudentPriceList= ls.stream()
			.filter(Student-> Student.price <30000)
			.map(Student->Student.price)
			.collect(Collectors.toSet());
	System.out.println(StudentPriceList);
	
	Map<Integer, String> StudentPriceMap= ls.stream()
		.collect(Collectors.toMap(cp->cp.Serialno, cp->cp.name));
	System.out.println(StudentPriceMap);
	
	List<Float> StudentPriceList1= ls.stream()
			.map(Student::getPrice)
			.collect(Collectors.toList());
	System.out.println(StudentPriceList1);
	
	
	}
}


