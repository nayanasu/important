import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import java.sql.Statement;

public class InsertExample {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		String url="jdbc:mysql://localhost:3306/school?useSSL=false";
		String uname="root";
		String pass= "1234";
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con= DriverManager.getConnection(url,uname,pass);
		String query="select max(ID) from Persons2";
		String query1="select max(Email) from Persons2";
		Statement st0=con.createStatement();
		ResultSet rs=st0.executeQuery(query);
		Statement st2=con.createStatement();
		ResultSet rs1=st2.executeQuery(query1);
		
		int tempId;
		rs.next();
		tempId=rs.getInt(1);
		int ID=tempId+1;
		
		String tempEmail;
		rs1.next();
		tempEmail=rs1.getString(4);
		String email=tempEmail+"abc";
		
		int iD=103 ;
		String lastNmae="SU";
		String firstName="Nayana";
		String Email="n@gmail.com";
		int Age=21;
		int Gender=2;
		String City="Shimogha";
		
		String insertSt="Insert into persons2 values"
				+ "("+ID+", '"+lastNmae+"', '"+firstName+"', '"+Email+"', "+Age+", "+Gender+", '"+City+"')";
		Statement st1=con.createStatement();
		st1.executeUpdate(insertSt);
		System.out.println("Record inserted...");
	}

}
