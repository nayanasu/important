import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


public class Test {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
			String url="jdbc:mysql://localhost:3306/school?useSSL=false";
			String uname="root";
			String pass= "1234";
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection(url,uname,pass);
		    String query="select Firstname, age from persons2";
		    Statement st=con.createStatement();
		    ResultSet rs=st.executeQuery(query);
		 
		    while(rs.next())
		    {
		    	String nm=rs.getString("Firstname");
		    	int ag=rs.getInt("age");
		    	System.out.print(nm);
		    	System.out.println("  " +ag);
		    	System.out.println();
		    }
		    con.close();
	}

}
