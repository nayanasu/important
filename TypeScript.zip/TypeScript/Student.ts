class Student {
	fullName: string;
	constructor(public firstName: string, public middleInitial: string, public lastName: string) {
		this.fullName = firstName + " " + middleInitial + " " + lastName;
	}
}


interface Person {
		firstName: string;
		lastName: string;
	}
 function greeter(person: Person) {
 	return "Hello, " +person.firstName + " " + person.lastName ;
}
 function greeter1(person: Person) {
 	return "Hello, " +person.lastName + " " + person.firstName ;
}

let user = new Student("ABC", "S.", "User");
console.log(greeter(user));
let user1 = new Student("MNO", "S.", "User");
console.log(greeter1(user));