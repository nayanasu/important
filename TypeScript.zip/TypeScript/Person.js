function greeter(person) {
    return "Hello, " + person.firstName + " " + person.lastName + " " + person.id;
}
var user = { firstName: "ABC", lastName: "User", id: 5 };
console.log(greeter(user));
