interface Person {
		firstName: string;
		lastName: string;
		id: number;
	}
 function greeter(person: Person) {
 	return "Hello, " +person.firstName + " " + person.lastName + " " + person.id;
}

let user = { firstName: "ABC", lastName: "User", id: 5};
console.log(greeter(user));