var Student = /** @class */ (function () {
    function Student(firstName, middleInitial, lastName) {
        this.firstName = firstName;
        this.middleInitial = middleInitial;
        this.lastName = lastName;
        this.fullName = firstName + " " + middleInitial + " " + lastName;
    }
    return Student;
}());
function greeter(person) {
    return "Hello, " + person.firstName + " " + person.lastName;
}
function greeter1(person) {
    return "Hello, " + person.lastName + " " + person.firstName;
}
var user = new Student("ABC", "S.", "User");
console.log(greeter(user));
var user1 = new Student("ABC", "S.", "User");
console.log(greeter1(user));
