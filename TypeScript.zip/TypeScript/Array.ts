let arrType:number[]|string[];
let i:number;
arrType=[1,2,3,4];
console.log("Numeric type array:")

for(i=0;i<arrType.length;i++){
console.log(arrType[i]);
}
arrType=["ABC", "XYZ", "MNO"];
console.log("String type array:")

for(i=0;i<arrType.length;i++){
console.log(arrType[i]);	
}