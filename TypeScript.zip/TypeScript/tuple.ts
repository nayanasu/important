let empTuple = ["ABC" , 21, "Java"];
console.log("Items: "+empTuple );
console.log("Length of tuple items before push: " +empTuple.length);
empTuple.push(10001);
console.log("Length of tuple items after push:" +empTuple.length);
console.log("Items:" +empTuple);